local isApplyingEffects = false
local isExtracting = false 

-- ==========================================
-- 1. VISUAL EFFECTS LOGIC
-- ==========================================
local function applyVirusEffects(virusType)
    local ped = PlayerPedId()
    if virusType == 'zombie' then
        SetTimecycleModifier("rply_vignette_neg") 
        SetTimecycleModifierStrength(0.9)
        ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.05)
        
        lib.requestAnimSet("move_m@drunk@verydrunk")
        SetPedMovementClipset(ped, "move_m@drunk@verydrunk", 1.0)
        
    elseif virusType == 'covid' then
        SetTimecycleModifier("spectator5")
        SetTimecycleModifierStrength(0.7)
        lib.requestAnimSet("move_m@injured")
        SetPedMovementClipset(ped, "move_m@injured", 1.0)

    elseif virusType == 'rage' then
        SetTimecycleModifier("emergency_heist_red")
        SetTimecycleModifierStrength(0.5)
        ShakeGameplayCam('DEATH_FAIL_IN_EFFECT_SHAKE', 0.1)
        lib.requestAnimSet("move_m@hurry@a")
        SetPedMovementClipset(ped, "move_m@hurry@a", 1.0)
    end
end
-- ==========================================
-- 2. TARGET ZONE INITIALIZATION
-- ==========================================
CreateThread(function()
    -- Wait a second to ensure Config is loaded
    Wait(1000) 
    
    if not Config.Locations then 
        print("^1[ERROR] Config.Locations is nil! Check your config.lua file.^7")
        return 
    end

    for k, loc in pairs(Config.Locations) do
        -- We'll use a slightly larger size and move Z back up a bit to ensure it's clickable
        exports.ox_target:addBoxZone({
            name = "pathogen_" .. k, -- Added unique name
            coords = vec3(loc.coords.x, loc.coords.y, loc.coords.z - 0.5), -- Adjusted to be less deep
            size = vec3(2.0, 2.0, 2.5), -- Made it slightly larger
            rotation = 0,
            debug = false, -- KEEP THIS TRUE UNTIL YOU SEE THE GREEN BOXES
            options = {
                {
                    label = loc.label,
                    icon = 'fas fa-biohazard',
                    onSelect = function()
                        if isExtracting then return end 
                        isExtracting = true
                        
                        if lib.progressBar({
                            duration = 5000,
                            label = 'Extracting Pathogen...',
                            useWhileDead = false,
                            canCancel = true,
                            anim = { 
                                dict = 'anim@amb@business@meth@meth_monitoring_cooking@monitoring@', 
                                clip = 'look_around_01_monitor' 
                            },
                            disable = { move = true, car = true }
                        }) then 
                            TriggerServerEvent('qbx_pathogens:server:giveVirus', loc.virus)
                        end
                        isExtracting = false
                    end
                }
            }
        })
    end
end)
-- ==========================================
-- 3. MAIN VIRUS & SPREAD LOOP
-- ==========================================
CreateThread(function()
    while true do
        local sleep = 1500
        local ped = PlayerPedId()
        
        -- Reliability Check
        local zombieCount = exports.ox_inventory:Search('count', 'virus_zombie') or 0
        local covidCount = exports.ox_inventory:Search('count', 'virus_covid') or 0
        local rageCount = exports.ox_inventory:Search('count', 'virus_rage') or 0
        
        local activeVirus = nil
        if zombieCount > 0 then activeVirus = 'zombie' 
        elseif covidCount > 0 then activeVirus = 'covid' 
        elseif rageCount > 0 then activeVirus = 'rage' end

        if activeVirus then
            sleep = 1000 
            isApplyingEffects = true
            applyVirusEffects(activeVirus)
            
            -- Re-apply blur every second if zombie (Simple call, no "if" check)
            if activeVirus == 'zombie' then
                TriggerScreenblurFadeIn(1000)
            end

            -- HEALTH TICK
            if math.random(1, 15) == 1 then
                local health = GetEntityHealth(ped)
                if health > 105 then 
                    SetEntityHealth(ped, health - 1)
                end
            end

            -- RANDOM SYMPTOMS
            if math.random(1, 100) > 95 then
                if activeVirus == 'covid' then
                    ExecuteCommand("me coughs violently")
                    if math.random(1, 10) > 7 then
                        SetPedToRagdoll(ped, 1500, 1500, 0, 0, 0, 0)
                    end
                elseif activeVirus == 'zombie' then
                    -- Using a very basic "Stumble" animation
                    local dict = "move_m@drunk@moderatedrunk_head_up"
                    lib.requestAnimDict(dict)
                    TaskPlayAnim(ped, dict, "idle_short", 8.0, 8.0, 2000, 49, 0, false, false, false)
                end
            end

            -- SPREAD LOGIC
            local nearbyPlayers = lib.getNearbyPlayers(GetEntityCoords(ped), 3.0)
            if nearbyPlayers then
                for i = 1, #nearbyPlayers do
                    TriggerServerEvent('qbx_pathogens:server:spreadVirus', GetPlayerServerId(nearbyPlayers[i].id), activeVirus)
                end
            end
        elseif isApplyingEffects then
            -- CLEANUP
            ClearTimecycleModifier()
            StopGameplayCamShaking(true)
            TriggerScreenblurFadeOut(500)
            ResetPedMovementClipset(ped, 0.0)
            isApplyingEffects = false
        end

        Wait(sleep)
    end
end)