fx_version 'cerulean'
game 'gta5'

description 'QBX Pathogens'
author 'lowkey'

-- This line is the magic fix:
shared_script '@ox_lib/init.lua'

client_scripts {
    'config.lua',
    'client/main.lua'
}

server_scripts {
    'server/main.lua'
}

dependencies {
    'qbx_core',
    'ox_lib',
    'ox_target',
    'ox_inventory'
}