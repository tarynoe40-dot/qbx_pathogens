Config = {}

Config.InfectionChance = 95 -- Added this to fix your "compare number with nil" error

Config.Locations = {
    {coords = vec3(3538.61, 3667.77, 28.12), virus = 'virus_zombie', label = 'Extract V-Alpha (Zombie)'},
    {coords = vec3(3535.00, 3662.36, 28.21), virus = 'virus_covid', label = 'Sample COVID-26'},
}