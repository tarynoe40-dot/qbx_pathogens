local extractionCooldowns = {}

RegisterNetEvent('qbx_pathogens:server:giveVirus', function(virusItem)
    local src = source
    print("^2[DEBUG]^7 Server received request for: " .. tostring(virusItem))

    -- 1. Security Check
    local validViruses = { ['virus_zombie'] = true, ['virus_covid'] = true, ['virus_rage'] = true }
    
    if not validViruses[virusItem] then
        print("^1[DEBUG]^7 Security Block: Invalid item name received: " .. tostring(virusItem))
        return
    end

    -- 2. Cooldown Check
    local extractionCooldowns = {}

RegisterNetEvent('qbx_pathogens:server:giveVirus', function(virusItem)
    local src = source
    local currentTime = os.time()
    
    -- Create a unique key for this player AND this specific virus
    local cooldownKey = src .. virusItem 

    if extractionCooldowns[cooldownKey] and (currentTime - extractionCooldowns[cooldownKey]) < 60 then
        local timeLeft = 60 - (currentTime - extractionCooldowns[cooldownKey])
        TriggerClientEvent('ox_lib:notify', src, {
            title = 'Extraction Failed',
            description = string.format('This pathogen needs time to regrow. Wait %s seconds.', timeLeft),
            type = 'error'
        })
        return
    end

    local success = exports.ox_inventory:AddItem(src, virusItem, 1)
    
    if success then
        extractionCooldowns[cooldownKey] = currentTime -- Save cooldown for this specific item
        -- ... rest of your success logic
    end
end)

    -- 3. Item Addition
    print("^2[DEBUG]^7 Attempting to add item to inventory...")
    local success = exports.ox_inventory:AddItem(src, virusItem, 1)
    
    if success then
        print("^2[DEBUG]^7 SUCCESS: Item added to ID " .. src)
        extractionCooldowns[src] = currentTime
        TriggerClientEvent('ox_lib:notify', src, { title = 'Success', description = 'Pathogen extracted.', type = 'success' })
    else
        print("^1[DEBUG]^7 FAIL: ox_inventory:AddItem returned false. Is the item in your items.lua?")
        TriggerClientEvent('ox_lib:notify', src, { title = 'Error', description = 'Inventory failed to add item.', type = 'error' })
    end
end)